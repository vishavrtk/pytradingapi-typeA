import os
import logging
from tradingapi_a.mconnect import MConnect
from tradingapi_a import __config__
from strategies.basic_strategy import run_strategy

# Logger setup
log_file = os.path.join("logs", "miraesdk_typeA.log")
logging.basicConfig(filename=log_file, format='%(asctime)s %(message)s', filemode='a')
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def main():
    mconnect = MConnect()
    
    logger.info("Logging in...")
    login_resp = mconnect.login("RAHUL", "Macm@123")
    logger.info(f"Login: {login_resp.json()}")

    logger.info("Generating session...")
    session = mconnect.generate_session(__config__.API_KEY, "123", "W")
    logger.info(f"Session: {session.json()}")

    # Run strategy
    run_strategy(mconnect, logger)

if __name__ == "__main__":
    main()
