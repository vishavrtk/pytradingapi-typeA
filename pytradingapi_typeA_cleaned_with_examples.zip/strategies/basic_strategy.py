def run_strategy(mconnect, logger):
    logger.info("Placing dummy buy order for SBICARD...")
    order_resp = mconnect.place_order("SBICARD", "NSE", "BUY", "MARKET", "10", "CNC", "DAY", "0", "0")
    logger.info(f"Order Response: {order_resp.json()}")

    logger.info("Fetching order book...")
    orders = mconnect.get_order_book()
    logger.info(f"Order Book: {orders.json()}")
