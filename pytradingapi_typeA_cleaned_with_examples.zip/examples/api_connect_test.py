from tradingapi_a.mconnect import MConnect
from tradingapi_a import __config__

m = MConnect()

# Login
login = m.login("RAHUL", "Macm@123")
print("Login Response:", login.json())

# Generate session
session = m.generate_session(__config__.API_KEY, "123", "W")
print("Session Response:", session.json())

# Access token
print("Access Token:", m.access_token)
